#ifndef _COLOR_H
#define _COLOR_H
#include "main.h"
#include "Adafruit_TCS34725.h"

void get_color();

void slider_rgb();

#endif
