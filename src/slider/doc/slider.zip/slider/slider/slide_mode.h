#ifndef _Slide_Mode_
#define _Slide_Mode_
#include <Arduino.h>
#include "main.h"

void slide_pick_up();

void slide_pick_down();

void uarm_slider_pick();

#endif
